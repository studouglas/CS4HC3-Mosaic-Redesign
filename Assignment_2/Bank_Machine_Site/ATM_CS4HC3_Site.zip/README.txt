Instructions
==============

1. Right click "index.html" and choose Open With > [browser] 
NOTE: the application does NOT work in Chrome, due to some security requirements of Chrome. It works in Safari, Firefox, EDGE, and modern versions of Internet Explorer. We developed on Chrome and Safari (our IDE creates a local server for Chrome so it works fine), so some small UI elements may not be aligned / proper in other browsers.

2. Use one of the following Account Number / Pin Number combos to login. Each account has different bank accounts and balances. Note that any updates to the balances will be saved in browser cache, so it is persistent until you clear your history or switch browsers.


Account Number / Pin Number
==============

12345 / 55555

11111 / 12345

98765 / 10202

55555 / 11223

10101 / 00000